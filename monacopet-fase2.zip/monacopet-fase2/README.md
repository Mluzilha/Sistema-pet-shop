# Monacopet Store

Sistema web de um petshop para cães e gatos, desenvolvido por **Rafael Monaco** na disciplina **Fundamentos de Sistemas Web** (PUCRS Online).

- **Fase 1:** estrutura em HTML puro (cabeçalho, produtos, serviços e rodapé).
- **Fase 2 (esta versão):** Bootstrap/CSS, JavaScript, cadastro de cliente e pet, agendamento e acessibilidade.

Site publicado: https://monacorafa10-png.github.io/MONACOPET/

## Páginas e funcionalidades

| Página | O que tem |
|---|---|
| `index.html` | Carrossel Bootstrap com 4 destaques, saudação (bom dia/tarde/noite), promoção que muda conforme o dia da semana, status "Aberto agora / Fechado", data e hora, atalhos para as áreas do site |
| `produtos.html` | 2 produtos de cada categoria (ração, brinquedos e higiene), com foto, descrição e valor, e filtro por categoria |
| `servicos.html` | Banho e tosa, com foto, descrição, valor, tele-busca e entrega no local |
| `cadastro.html` | Formulário do cliente (nome, CPF, nascimento, sexo, telefone, e-mail, endereço, contato) e do pet (nome, espécie, raça, idade, porte, peso, observações) |
| `agendamento.html` | Escolha do serviço, do método (tele-busca ou entrega no local), do dia (calendário) e do horário, com resumo e valor total |

### Requisitos da Fase 2

- **CSS/Bootstrap e JavaScript:** Bootstrap 5 (grade, navbar, cartões, formulários, carrossel) + `css/style.css` com a identidade visual. Funções temporais em `js/comum.js` (saudação, relógio, aberto/fechado, promoção do dia) e restrições de data e horário em `js/agendamento.js`.
- **Formulário de cadastro:** usa `input` de texto, `email`, `tel`, `date`, `number`, `radio`, `checkbox`, `select` e `textarea`, com `placeholder`, `required`, `pattern`, `min`, `max` e `maxlength`. CPF, telefone e CEP têm máscara automática; o CPF tem validação dos dígitos verificadores.
- **Escolha do serviço e agendamento:** serviços banho e tosa; método tele-busca (pede o endereço) ou entrega no local; dia escolhido no calendário (`input type="date"`) e horário numa lista que bloqueia horários ocupados ou passados.
- **Acessibilidade para deficientes visuais:** ver a seção abaixo.

## Acessibilidade

- Atributo `alt` descritivo em todas as imagens (audiodescrição).
- Link "Ir para o conteúdo principal" para quem usa teclado ou leitor de tela.
- Botões **A-**, **A+** e **Contraste** (alto contraste) no topo de todas as páginas; a escolha fica salva.
- Todos os campos têm `label`; grupos de opções usam `fieldset` e `legend`; mensagens de erro e de confirmação são lidas por leitores de tela (`role="status"`, `aria-live`).
- Foco do teclado bem visível, menu com `aria-current`, carrossel com rótulos e botões acessíveis, e respeito à preferência "reduzir movimento" do sistema.
- `lang="pt-BR"` e títulos organizados (um `h1` por página).

## Estrutura de arquivos

```
MONACOPET/
├── index.html
├── produtos.html
├── servicos.html
├── cadastro.html
├── agendamento.html
├── README.md
├── css/
│   └── style.css          estilos próprios e modo de alto contraste
├── js/
│   ├── comum.js           funções temporais, acessibilidade, armazenamento
│   ├── produtos.js        filtro de produtos
│   ├── cadastro.js        máscaras e validação do cadastro
│   └── agendamento.js     calendário, horários e agendamentos
└── imagens/
    ├── racao-cachorro.jpg  racao-gato.jpg  bolinha.jpg
    ├── arranhador.jpg      shampoo.jpg     tapete.jpg
    └── banho.jpg           tosa.jpg
```

Todo o código JavaScript, CSS e HTML está comentado em português.

## Ajustes realizados (da Fase 1 para a Fase 2)

Para reduzir problemas antes da publicação, foram feitos estes ajustes:

1. **Nome do arquivo de serviços:** `serviços.html` (com cedilha e acento) virou `servicos.html`. O nome com acento quebrava o link do menu no GitHub Pages.
2. **Organização em pastas:** CSS, JavaScript e imagens agora ficam em `css/`, `js/` e `imagens/`, em vez de tudo na raiz do repositório. As imagens ganharam nomes padronizados, sem espaços ou acentos.
3. **Formato das imagens:** as fotos eram arquivos `.webp`, `.png` e `.jpeg` renomeados para `.jpg`. Foram convertidas para JPEG de verdade e reduzidas (no máximo 800 px), o que evita imagens quebradas e deixa o site mais leve. A foto da ração de gato tinha fundo transparente e ganhou fundo branco.
4. **Serviços:** a Fase 1 listava banho, tosa, consulta veterinária e vacinação. O enunciado da Fase 2 define 2 serviços, então o site passou a ter só **banho e tosa**.
5. **Tabelas viraram cartões Bootstrap:** produtos e serviços saíram das tabelas de HTML puro e agora usam cartões responsivos, que se adaptam ao celular.
6. **Navegação:** o menu agora tem páginas de cadastro e agendamento, vira botão (hambúrguer) no celular e marca a página atual.
7. **Autoria:** o rodapé e este README passaram a indicar **Rafael Monaco** (antes constava outro nome).
8. **Dados fictícios identificados:** o rodapé informa que nomes, preços e contatos são fictícios.
9. **Descrições de imagem (`alt`):** reescritas para descrever de fato o que aparece em cada foto.
10. **Validação e proteção do cadastro:** campos obrigatórios, CPF com dígitos verificadores, cliente maior de 18 anos, idade do pet limitada, aceite da LGPD. Textos digitados são inseridos na página com `textContent`, e não como HTML, o que evita injeção de código.
11. **Agendamento sem conflitos:** não aceita datas passadas, domingos (loja fechada) nem horários já reservados; se for hoje, só libera horários com pelo menos 1 hora de antecedência. A data é calculada no fuso local, para não "virar o dia" à noite.
12. **Armazenamento seguro:** se o navegador bloquear o `localStorage`, o site continua funcionando e avisa que os dados não ficarão salvos.
13. **Endereço da tele-busca:** só é pedido (e só é obrigatório) quando a tele-busca é escolhida.
14. **Carrossel acessível:** pausa automaticamente para quem prefere menos movimento.

## Observações

- Os dados de cadastro e agendamento ficam salvos apenas no navegador de quem usa (`localStorage`); não há servidor.
- Nomes, preços, telefone, e-mail e endereço da loja são fictícios, criados para fins acadêmicos.
- As imagens ilustram o trabalho acadêmico.
